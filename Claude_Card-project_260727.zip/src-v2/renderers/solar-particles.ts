import { svg, TemplateResult } from "lit";
import { SolarAnimationProfile } from "../core/animation-profile";

interface Point {
    x: number;
    y: number;
}

/**
 * Deterministic pseudo-random, seeded by particle index.
 *
 * Deliberately NOT Math.random(): this file is re-rendered on
 * every hass update. A random value that changes between renders
 * would change the SMIL attributes on the same DOM nodes, which
 * makes the animation visibly restart/jump (the same bug fixed
 * for label pulse/glow). Seeding by index keeps every particle's
 * jitter fixed across renders, while still differing from its
 * siblings.
 */
function pseudoRandom(seed: number): number {
    const x = Math.sin(seed * 12.9898) * 43758.5453;
    return x - Math.floor(x);
}

function renderParticle(
    index: number,
    from: Point,
    to: Point,
    duration: number
): TemplateResult {

    const jitterX = pseudoRandom(index * 7.31) - 0.5;
    const jitterY = pseudoRandom(index * 13.7 + 3) - 0.5;
    const curveJitter = pseudoRandom(index * 19.1 + 11) - 0.5;
    const beginOffset = pseudoRandom(index * 5.13 + 9) * duration;
    const sizeFactor = 0.7 + pseudoRandom(index * 2.9 + 17) * 0.6;
    const durationFactor = 0.85 + pseudoRandom(index * 3.7 + 23) * 0.3;

    const dx = to.x - from.x;
    const dy = to.y - from.y;

    const perpX = -dy;
    const perpY = dx;
    const perpLength = Math.max(1, Math.hypot(perpX, perpY));
    const curveAmount = curveJitter * 26;

    const controlX =
        (from.x + to.x) / 2 + (perpX / perpLength) * curveAmount;
    const controlY =
        (from.y + to.y) / 2 + (perpY / perpLength) * curveAmount;

    const startX = from.x + jitterX * 14;
    const startY = from.y + jitterY * 14;

    const path = `M ${startX} ${startY} Q ${controlX} ${controlY} ${to.x} ${to.y}`;

    const particleDuration = duration * durationFactor;
    const radius = 1.4 * sizeFactor;

    return svg`
        <circle
            r="${radius}"
            fill="#FFE9A8"
            opacity="0"
        >
            <animateMotion
                dur="${particleDuration}s"
                begin="-${beginOffset}s"
                repeatCount="indefinite"
                calcMode="spline"
                keySplines="0.3 0 0.7 1"
                path="${path}"
            />
            <animate
                attributeName="opacity"
                values="0;0.55;0.55;0"
                keyTimes="0;0.15;0.7;1"
                dur="${particleDuration}s"
                begin="-${beginOffset}s"
                repeatCount="indefinite"
            />
        </circle>
    `;
}

export function renderSolarParticles(
    from: Point,
    to: Point,
    profile: SolarAnimationProfile
): TemplateResult {

    if (profile.particleCount <= 0) {
        return svg``;
    }

    return svg`
        ${Array.from({ length: profile.particleCount }).map((_, i) =>
            renderParticle(i, from, to, profile.duration)
        )}
    `;
}
