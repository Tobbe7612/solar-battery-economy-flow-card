import {
    getNumber,
    getString,
    getAttribute,
} from "../utils/entity";

export interface CardData {
    solarPower: number;
    solarStatus: string;
    solarEntity: string;

  batteryToHouse: number;
  solarExportEnergy: number;
  gridToHouseEnergy: number;

    batteryUtilization: number;
    batteryUtilizationEntity: string;
    savingsToday: number;
    savingsTodayEntity: string;
    totalSavings: number;
    totalSavingsEntity: string;
    roi: number;
    roiEntity: string;

    gridIndependence: number;
    gridIndependenceEntity: string;
    co2Saved: number;
    co2SavedEntity: string;
    solarSelfConsumptionRate: number;
    solarSelfConsumptionRateEntity: string;

    batterySoc: number;
    batteryPower: number;
    batteryStatus: string;
    batteryEntity: string;

    housePower: number;
    houseStatus: string;
    houseEntity: string;

    gridPower: number;
    gridStatus: string;
    gridEntity: string;

    carPower: number;
    carSoc: number;
    carStatus: string;
    carEntity: string;

    spaPower: number;
    spaTemperature: number;
    spaStatus: string;
    spaEntity: string;

    heatpumpPower: number;
    heatpumpStatus: string;
    heatpumpEntity: string;

    appliancePower: number;
    applianceStatus: string;
    applianceEntity: string;

    importToday: number;
    importTodayEntity: string;
    exportToday: number;
    exportTodayEntity: string;

    savingsThisMonth: number;
    savingsThisMonthEntity: string;
    savingsThisYear: number;
    savingsThisYearEntity: string;
    estimatedAnnualSavings: number;
    estimatedAnnualSavingsEntity: string;
    paybackTime: number | string;
    paybackTimeEntity: string;
}

export function getCardData(
  hass: any
): CardData {

  const solarPower =
    getNumber(
        hass,
        "sensor.solar_battery_economy_energy_system_power_solar_house"
    )
    +
    getNumber(
        hass,
        "sensor.solar_battery_economy_energy_system_power_solar_battery"
    )
    +
    getNumber(
        hass,
        "sensor.solar_battery_economy_energy_system_power_solar_export"
    );

  const solarStatus =
    getString(hass, "sun.sun") === "above_horizon"
        ? "Över horisonten"
        : "Under horisonten";

  const batteryUtilization =
    getNumber(
      hass,
      'sensor.solar_battery_economy_financial_31_battery_utilization'
    );

  const savingsToday =
    getNumber(
      hass,
      'sensor.solar_battery_economy_financial_03_savings_today'
    );

  const co2Saved =
    getNumber(
      hass,
      'sensor.solar_battery_economy_financial_33_co2_saved'
    );

  const solarSelfConsumptionRate =
    getNumber(
      hass,
      'sensor.solar_battery_economy_financial_32_solar_self_consumption_rate'
    );

  const batteryToHouse =
    getNumber(
      hass,
      'sensor.solar_battery_economy_energy_system_energy_battery_house'
    );

  const solarExportEnergy =
    getNumber(
      hass,
      'sensor.solar_battery_economy_energy_system_energy_solar_export'
    );

  const gridToHouseEnergy =
    getNumber(
      hass,
      'sensor.solar_battery_economy_energy_system_energy_grid_house'
    );

  const totalSavings =
    getNumber(
      hass,
      'sensor.solar_battery_economy_financial_01_total_savings'
    );

    const roi =
        getNumber(
            hass,
            "sensor.solar_battery_economy_financial_12_return_on_investment"
        );

    const importToday =
        getNumber(
            hass,
            "sensor.import_idag"
        );

    const exportToday =
        getNumber(
            hass,
            "sensor.export_idag"
        );

    const savingsThisMonth =
        getNumber(
            hass,
            "sensor.solar_battery_economy_financial_04_savings_this_month"
        );

    const savingsThisYear =
        getNumber(
            hass,
            "sensor.solar_battery_economy_financial_05_savings_this_year"
        );

    const estimatedAnnualSavings =
        getNumber(
            hass,
            "sensor.solar_battery_economy_financial_02_estimated_annual_savings"
        );

    const paybackTime =
        getNumber(
            hass,
            "sensor.solar_battery_economy_financial_10_payback_time"
        );

  const gridIndependence =
    getNumber(
      hass,
      'sensor.solar_battery_economy_financial_30_grid_independence'
    );

  const batterySoc =
    getNumber(
      hass,
      "sensor.saj_battery_energy_percent"
    );

  const batteryPower =
    getNumber(
      hass,
      "sensor.saj_realtime_battery_power"
    );

  // SAJ:
  //  + batteryPower = Batteriet levererar effekt (urladdar)
  //  - batteryPower = Batteriet tar emot effekt (laddar)
  const batteryStatus =
      batteryPower < -1
          ? "Laddar"
          : batteryPower > 1
              ? "Urladdar"
              : "Standby";

  const solarToHouse =
      getNumber(
          hass,
          "sensor.solar_battery_economy_energy_system_power_solar_house"
      );

  const batteryToHousePower =
      getNumber(
          hass,
          "sensor.solar_battery_economy_energy_system_power_battery_house"
      );

  const gridToHousePower =
      getNumber(
          hass,
          "sensor.solar_battery_economy_energy_system_power_grid_house"
      );

  const housePower =
      solarToHouse +
      batteryToHousePower +
      gridToHousePower;

  const houseSources: string[] = [];

  if (solarToHouse > 1) {
      houseSources.push("Sol");
  }

  if (batteryToHousePower > 1) {
      houseSources.push("Batteri");
  }

  if (gridToHousePower > 1) {
      houseSources.push("Elnät");
  }

  const houseStatus =
      houseSources.length > 0
          ? houseSources.join(" + ")
          : "Ingen last";

  const houseToGridPower =
      getNumber(
          hass,
          "sensor.solar_battery_economy_energy_system_power_house_grid"
      );

  const batteryToGridPower =
      getNumber(
          hass,
          "sensor.solar_battery_economy_energy_system_power_battery_grid"
      );
    const gridToBatteryPower =
        getNumber(
            hass,
            "sensor.solar_battery_economy_energy_system_power_grid_battery"
        );

    const solarToGridPower =
        getNumber(
            hass,
            "sensor.solar_battery_economy_energy_system_power_solar_export"
        );

  const gridPower =
        gridToHousePower +
        gridToBatteryPower -
        houseToGridPower -
        batteryToGridPower -
        solarToGridPower;

  const gridStatus =
      gridPower > 1
          ? "Importerar"
          : gridPower < -1
              ? "Exporterar"
              : "Balans";

  const carPower =
      getNumber(
          hass,
          "sensor.volvo_ec40_charging_power"
      );

  const carSoc =
      getNumber(
          hass,
          "sensor.volvo_ec40_batteri"
      );

  const carStatus =
      getString(
          hass,
          "sensor.volvo_ec40_charging_status",
          "Okänd"
      );

  const spaPower =
      getNumber(
          hass,
          "sensor.plugg_spabad_power"
      );

  const spaTemperature =
      getAttribute<number>(
          hass,
          "climate.spa_thermostat",
          "current_temperature",
          0
      );

  const hvacMode =
      getString(
          hass,
          "climate.spa_thermostat"
      );

  const hvacAction =
      getAttribute<string>(
          hass,
          "climate.spa_thermostat",
          "hvac_action",
          ""
      );

  const spaStatus =
      hvacMode === "off"
          ? "Av"
          : hvacAction === "heating"
              ? "Värmer"
              : "Standby";

  const heatpumpPower =
      getNumber(
          hass,
          "sensor.thermia_power_estimator_total_effekt"
      );

  const heatpumpStatus =
      getString(
          hass,
          "sensor.thermia_power_estimator_driftlage",
          "Okänd"
      );

  const appliancePower =
      getNumber(
          hass,
          "sensor.vitvaror_effekt"
      );

  const applianceStatus =
      appliancePower > 1
          ? "Aktiv"
          : "Standby";
 
  return {

    solarPower,
    solarStatus,
    solarEntity:
        "sensor.solaredge_ac_power",

    batteryToHouse,
    solarExportEnergy,
    gridToHouseEnergy,

    batteryUtilization,
    batteryUtilizationEntity:
        "sensor.solar_battery_economy_financial_31_battery_utilization",
    savingsToday,
    savingsTodayEntity:
        "sensor.solar_battery_economy_financial_03_savings_today",
    totalSavings,
    totalSavingsEntity:
        "sensor.solar_battery_economy_financial_01_total_savings",
    roi,
    roiEntity:
        "sensor.solar_battery_economy_financial_12_return_on_investment",

    importToday,
    importTodayEntity:
        "sensor.import_idag",

    exportToday,
    exportTodayEntity:
        "sensor.export_idag",

    savingsThisMonth,
    savingsThisMonthEntity:
        "sensor.solar_battery_economy_financial_04_savings_this_month",

    savingsThisYear,
    savingsThisYearEntity:
        "sensor.solar_battery_economy_financial_05_savings_this_year",

    estimatedAnnualSavings,
    estimatedAnnualSavingsEntity:
        "sensor.solar_battery_economy_financial_02_estimated_annual_savings",

    paybackTime,
    paybackTimeEntity:
        "sensor.solar_battery_economy_financial_10_payback_time",

    gridIndependence,
    gridIndependenceEntity:
        "sensor.solar_battery_economy_financial_30_grid_independence",
    co2Saved,
    co2SavedEntity:
        "sensor.solar_battery_economy_financial_33_co2_saved",
    solarSelfConsumptionRate,
    solarSelfConsumptionRateEntity:
        "sensor.solar_battery_economy_financial_32_solar_self_consumption_rate",

    batterySoc,
    batteryPower,
    batteryStatus,
    batteryEntity:
        "sensor.saj_realtime_battery_power",

    housePower,
    houseStatus,
    houseEntity:
        "sensor.forbrukning_nu_ny",

    gridPower,
    gridStatus,
    gridEntity:
        "sensor.effekt_alla_faser",

    carPower,
    carSoc,
    carStatus,
    carEntity:
        "sensor.volvo_ec40_charging_power",

    spaPower,
    spaTemperature,
    spaStatus,
    spaEntity:
        "sensor.plugg_spabad_power",

    heatpumpPower,
    heatpumpStatus,
    heatpumpEntity:
        "sensor.thermia_power_estimator_total_effekt",

    appliancePower,
    applianceStatus,
    applianceEntity:
        "sensor.vitvaror_effekt",
  };
}
