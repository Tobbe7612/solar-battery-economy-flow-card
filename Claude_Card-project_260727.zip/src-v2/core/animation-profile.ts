/**
 * ============================================================
 * Animation Profile
 * ============================================================
 * Central entry point for the card's animation system.
 *
 * Today only the "flow" domain exists (energy particle flows) —
 * moved here from renderers/graph/particle-profile.ts without
 * any change in behavior.
 *
 * "labels" and "solar" will be added here in a later phase as
 * additional keys on AnimationProfile. Call sites that only
 * need .flow (like render-edge-v2.ts) will not need to change
 * when that happens.
 */

import { getAnimationLevel } from "./animation-settings";

export interface FlowAnimationProfile {

    particleCount: number;

    duration: number;

    flowWidth: number;

    trailOpacity: number;

}

export interface AnimationProfile {

    flow: FlowAnimationProfile;

    // labels: added in a later phase.
    // solar: added in a later phase.

}

function getFlowAnimationProfile(
    power: number
): FlowAnimationProfile {

    const p = Math.abs(power);

    if (p < 300) {

        return {

            particleCount: 2,

            duration: 6.0,

            flowWidth: 5,

            trailOpacity: 0.18,

        };

    }

    if (p < 800) {

        return {

            particleCount: 3,

            duration: 5.2,

            flowWidth: 6,

            trailOpacity: 0.20,

        };

    }

    if (p < 1500) {

        return {

            particleCount: 4,

            duration: 4.4,

            flowWidth: 7,

            trailOpacity: 0.22,

        };

    }

    if (p < 3000) {

        return {

            particleCount: 6,

            duration: 3.7,

            flowWidth: 8,

            trailOpacity: 0.25,

        };

    }

    if (p < 5000) {

        return {

            particleCount: 8,

            duration: 3.0,

            flowWidth: 9,

            trailOpacity: 0.28,

        };

    }

    return {

        particleCount: 10,

        duration: 2.2,

        flowWidth: 10,

        trailOpacity: 0.30,

    };

}

export function getAnimationProfile(
    power: number
): AnimationProfile {

    return {
        flow: getFlowAnimationProfile(power),
    };

}

/**
 * ============================================================
 * Label animation (glow + pulse)
 * ============================================================
 * Both glow and pulse are power-independent, gentle "breathing"
 * effects driven by CSS (see styles/label-styles.ts) — not SMIL,
 * since the label tree is rewritten on every hass update and
 * SMIL animations there are prone to visibly restarting.
 *
 * Glow's target opacity/blur still scale with how much power the
 * node currently carries; pulse's scale/duration are fixed
 * constants shared by every active node.
 */

export interface LabelAnimationProfile {

    glow: {
        active: boolean;
        color: string;
        opacity: number;
        blur: number;
    };

    pulse: {
        active: boolean;
        scale: number;
        duration: number;
    };

}

const LABEL_PULSE_SCALE = 1.015;
const LABEL_PULSE_DURATION = 3.2;

function getLabelGlow(
    power: number,
    color: string
): LabelAnimationProfile["glow"] {

    const p = Math.abs(power);

    if (p <= 1) {
        return { active: false, color, opacity: 0, blur: 0 };
    }

    if (p < 300) {
        return { active: true, color, opacity: 0.03, blur: 8 };
    }

    if (p < 800) {
        return { active: true, color, opacity: 0.045, blur: 10 };
    }

    if (p < 1500) {
        return { active: true, color, opacity: 0.06, blur: 12 };
    }

    if (p < 3000) {
        return { active: true, color, opacity: 0.08, blur: 14 };
    }

    if (p < 5000) {
        return { active: true, color, opacity: 0.10, blur: 16 };
    }

    return { active: true, color, opacity: 0.12, blur: 18 };

}

export function getLabelAnimationProfile(
    power: number,
    color: string
): LabelAnimationProfile {

    if (getAnimationLevel() === "reduced") {
        return {
            glow: { active: false, color, opacity: 0, blur: 0 },
            pulse: { active: false, scale: 1, duration: LABEL_PULSE_DURATION },
        };
    }

    return {
        glow: getLabelGlow(power, color),
        pulse: {
            active: Math.abs(power) > 1,
            scale: LABEL_PULSE_SCALE,
            duration: LABEL_PULSE_DURATION,
        },
    };

}

/**
 * ============================================================
 * Solar particles
 * ============================================================
 * Loose, dust-like particles drifting from the sun (on the arc)
 * toward the SOL label. Count scales with current solar power;
 * duration is a fixed, power-independent drift time. Each
 * particle's own jittered path/timing is generated deterministically
 * from its index in renderers/solar-particles.ts — never from
 * Math.random() — for the same reason pulse/glow moved off SMIL
 * for labels: a value that changes on every re-render would make
 * the animation visibly restart.
 */

export interface SolarAnimationProfile {
    particleCount: number;
    duration: number;
}

const SOLAR_PARTICLE_DURATION = 3.5;

export function getSolarAnimationProfile(
    power: number
): SolarAnimationProfile {

    if (getAnimationLevel() === "reduced") {
        return { particleCount: 0, duration: SOLAR_PARTICLE_DURATION };
    }

    const p = Math.max(0, power);

    if (p <= 0) {
        return { particleCount: 0, duration: SOLAR_PARTICLE_DURATION };
    }

    if (p < 500) {
        return { particleCount: 4, duration: SOLAR_PARTICLE_DURATION };
    }

    if (p < 1500) {
        return { particleCount: 8, duration: SOLAR_PARTICLE_DURATION };
    }

    if (p < 3000) {
        return { particleCount: 12, duration: SOLAR_PARTICLE_DURATION };
    }

    return { particleCount: 15, duration: SOLAR_PARTICLE_DURATION };

}
