import { SceneLayout } from '../types/layout';

export const desktopLayout: SceneLayout = {

  sceneWidth: 1920,
  sceneHeight: 1080,

  nodes: {

    solar: {
      id: 'solar',
      label: 'SOL',

      x: 820,
      y: 180,

      width: 300,
      height: 140
    },

    house: {
      id: 'house',
      label: 'HUSET',

      x: 930,
      y: 650,

      width: 220,
      height: 125
    },

    battery: {
      id: 'battery',
      label: 'BATTERI',

      x: 1320,
      y: 420,

      width: 180,
      height: 130
    },

    grid: {
      id: 'grid',
      label: 'ELNÄT',

      x: 300,
      y: 420,

      width: 180,
      height: 130
    },

    spa: {
      id: 'spa',
      label: 'SPA',

      x: 400,
      y: 850,

      width: 170,
      height: 100
    },

    heatpump: {
      id: 'heatpump',
      label: 'VP',

      x: 700,
      y: 850,

      width: 140,
      height: 70
    },

    appliance: {
      id: 'appliance',
      label: 'APP',

      x: 900,
      y: 850,

      width: 140,
      height: 70
    },

    car: {
      id: 'car',
      label: 'BIL',

      x: 1200,
      y: 850,

      width: 170,
      height: 100
    }
  }
};